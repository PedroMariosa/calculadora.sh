#!/bin/bash
# Crinado uma calculadora 
cd /
ls -l
operação = input('+ , - ,* ,*')
num1 = float(input('digite um numero')
num2 = float(input('digite um numero')
if operação == '+':
	resultado = num1 + num2 
elif operação == '-':
	resultado = num1 - num2
elif operação == '*':
	resultado = num1 * num2
elif operadort ==' /'
	resultado = num1 / num2
else:
	resultado = 'resultado invalido'
	print(f' o resultado é:{resultado}')

	
